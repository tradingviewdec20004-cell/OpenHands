import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";

import { HomeAutomationRunTooltip } from "#/components/features/home/featured-automations/home-automation-run-tooltip";
import type { LatestAutomationRunState } from "#/hooks/query/use-latest-automation-runs";
import {
  AutomationRunStatus,
  type Automation,
  type AutomationRun,
} from "#/types/automation";

vi.mock("react-i18next", () => ({
  useTranslation: () => ({
    // Counted keys keep their count, so a test can assert which relative-time
    // key was chosen *and* the number handed to it, not just the key.
    t: (key: string, options?: Record<string, unknown>) =>
      options?.count === undefined ? key : `${key}:${options.count}`,
    i18n: { language: "en" },
  }),
}));

const automation: Automation = {
  id: "auto-1",
  name: "Release notes drafter",
  prompt: "Draft release notes",
  trigger: { type: "cron", schedule: "0 12 * * 5" },
  enabled: true,
  created_at: "2026-01-01T00:00:00Z",
  updated_at: "2026-01-01T00:00:00Z",
};

function makeRun(overrides: Partial<AutomationRun> = {}): AutomationRun {
  return {
    id: "run-1",
    status: AutomationRunStatus.RUNNING,
    conversation_id: null,
    bash_command_id: null,
    error_detail: null,
    started_at: "2026-08-01T10:00:00Z",
    completed_at: null,
    ...overrides,
  };
}

function makeState(run: AutomationRun | null): LatestAutomationRunState {
  return {
    latestRun: run,
    recentRuns: run ? [run] : [],
    isLoading: false,
    isError: false,
  };
}

// The row that opens this hovercard clips a long phase; the hovercard is the
// place where the whole phase has to be readable.
const LONG_LABEL =
  "Rendering the changelog for 37 merged pull requests across 4 repositories";

describe("HomeAutomationRunTooltip — phase", () => {
  it("shows the phase of a running run in full", () => {
    render(
      <HomeAutomationRunTooltip
        automation={automation}
        runState={makeState(makeRun({ current_phase: LONG_LABEL }))}
      />,
    );

    expect(screen.getByTestId("run-phase-row")).toHaveTextContent(LONG_LABEL);
  });

  it("omits the phase row for a finished run, matching every other surface", () => {
    render(
      <HomeAutomationRunTooltip
        automation={automation}
        runState={makeState(
          makeRun({
            status: AutomationRunStatus.COMPLETED,
            completed_at: "2026-08-01T10:05:00Z",
            current_phase: "Agent is working on the task",
          }),
        )}
      />,
    );

    expect(screen.queryByTestId("run-phase-row")).not.toBeInTheDocument();
  });

  it("omits the phase row when the run never reported one", () => {
    render(
      <HomeAutomationRunTooltip
        automation={automation}
        runState={makeState(makeRun())}
      />,
    );

    expect(screen.queryByTestId("run-phase-row")).not.toBeInTheDocument();
  });
});

describe("HomeAutomationRunTooltip — task outcome", () => {
  it("shows completed run task outcome and summary instead of infra error copy", () => {
    render(
      <HomeAutomationRunTooltip
        automation={automation}
        runState={makeState(
          makeRun({
            status: AutomationRunStatus.COMPLETED,
            completed_at: "2026-08-01T10:05:00Z",
            error_detail: "HUBSPOT_API_KEY was unavailable.",
            run_metadata: {
              finish_tool_response: {
                status: "blocked",
                outcome_summary:
                  "Attempted HubSpot CRM contact search but HUBSPOT_API_KEY was unavailable.",
              },
            },
          }),
        )}
      />,
    );

    expect(screen.getByText("AUTOMATIONS$DETAIL$BLOCKED")).toBeInTheDocument();
    expect(
      screen.getByText("AUTOMATIONS$DETAIL$TASK_LABEL"),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        "Attempted HubSpot CRM contact search but HUBSPOT_API_KEY was unavailable.",
      ),
    ).toBeInTheDocument();
    expect(
      screen.queryByText("HUBSPOT_API_KEY was unavailable."),
    ).not.toBeInTheDocument();
  });
});

describe("HomeAutomationRunTooltip — disabled reason", () => {
  it("surfaces an automatic-pause reason on an inactive automation", () => {
    const reason =
      "Paused automatically: auth — Invalid API key. This failed the last 3 runs and needs a configuration fix.";
    render(
      <HomeAutomationRunTooltip
        automation={{
          ...automation,
          enabled: false,
          disabled_reason: reason,
          disabled_detail: {
            reason: "consecutive_permanent_failures",
            source: "consecutive_permanent_failures",
          },
        }}
        runState={makeState(null)}
      />,
    );

    expect(screen.getByTestId("automation-tooltip-disabled-reason")).toHaveTextContent(
      reason,
    );
  });

  it("substitutes the manual-disable label instead of the raw 'manual' value", () => {
    render(
      <HomeAutomationRunTooltip
        automation={{
          ...automation,
          enabled: false,
          disabled_reason: "manual",
          disabled_detail: { reason: "manual", source: "user" },
        }}
        runState={makeState(null)}
      />,
    );

    expect(screen.getByTestId("automation-tooltip-disabled-reason")).toHaveTextContent(
      "AUTOMATIONS$DETAIL$DISABLED_MANUAL",
    );
  });

  it("omits the disabled-reason row for an enabled automation", () => {
    render(
      <HomeAutomationRunTooltip
        automation={{ ...automation, enabled: true, disabled_reason: null }}
        runState={makeState(makeRun())}
      />,
    );

    expect(
      screen.queryByTestId("automation-tooltip-disabled-reason"),
    ).not.toBeInTheDocument();
  });
});
