import { render, screen, waitFor, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { PluginLaunchModal } from "#/components/features/launch/plugin-launch-modal";
import { PluginSpec } from "#/api/conversation-service/agent-server-conversation-service.types";
import type { SchemaFormField } from "#/utils/plugin-launch-preflight";

const mockOnStartConversation = vi.fn();
const mockOnInstallAutomation = vi.fn();
const mockOnClose = vi.fn();

function renderModal(
  plugins: PluginSpec[],
  props: Partial<{
    message: string;
    isLoading: boolean;
    parametersSupported: boolean;
    mode: "conversation" | "automation";
    preflight: {
      description?: string | null;
      resolvedRef?: string | null;
      fields: SchemaFormField[];
      suggestedTrigger?: {
        type: string;
        schedule?: string;
        timezone?: string;
      } | null;
    } | null;
  }> = {},
) {
  const queryClient = new QueryClient({
    defaultOptions: { queries: { retry: false } },
  });

  return render(
    <QueryClientProvider client={queryClient}>
      <PluginLaunchModal
        plugins={plugins}
        parametersSupported={props.parametersSupported ?? true}
        message={props.message}
        isLoading={props.isLoading ?? false}
        mode={props.mode ?? "conversation"}
        preflight={props.preflight ?? null}
        onStartConversation={mockOnStartConversation}
        onInstallAutomation={
          props.mode === "automation" ? mockOnInstallAutomation : undefined
        }
        onClose={mockOnClose}
      />
    </QueryClientProvider>,
  );
}

describe("PluginLaunchModal", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("Plugin Display Name Extraction", () => {
    it("should extract plugin name from repo_path when provided", () => {
      renderModal([
        { source: "github:owner/repo", repo_path: "plugins/my-plugin" },
      ]);

      // Plugin name should be "my-plugin" from the path
      expect(screen.getByText("my-plugin")).toBeInTheDocument();
    });

    it("should show repo path when no repo_path (repo IS the plugin)", () => {
      renderModal([{ source: "github:owner/my-plugin" }]);

      // When no repo_path, the whole repo is the plugin, show "owner/my-plugin"
      const elements = screen.getAllByText("owner/my-plugin");
      expect(elements.length).toBeGreaterThan(0);
    });

    it("should extract name from git URL", () => {
      renderModal([{ source: "https://github.com/owner/repo-name.git" }]);

      const elements = screen.getAllByText("repo-name");
      expect(elements.length).toBeGreaterThan(0);
    });

    it("should display full source when no special format", () => {
      renderModal([{ source: "local-plugin" }]);

      const elements = screen.getAllByText("local-plugin");
      expect(elements.length).toBeGreaterThan(0);
    });
  });

  describe("Modal Title", () => {
    it("should show plugin name in title for single plugin", () => {
      renderModal([{ source: "github:owner/awesome-plugin" }]);

      // Title should include the plugin name - use getAllBy since text appears in multiple places
      const elements = screen.getAllByText(/owner\/awesome-plugin/);
      expect(elements.length).toBeGreaterThan(0);
    });

    it("should show generic title for multiple plugins", () => {
      renderModal([
        { source: "github:owner/plugin1" },
        { source: "github:owner/plugin2" },
      ]);

      // The generic title already contains the verb, so "Launch" is not
      // prepended again ("Launch Launch Plugin").
      const title = screen.getByRole("heading", { level: 2 });
      expect(title.textContent).toBe("LAUNCH$MODAL_TITLE_GENERIC");
    });
  });

  describe("Message Display", () => {
    it("should display message when provided", () => {
      renderModal([{ source: "github:owner/repo" }], {
        message: "This is a custom message",
      });

      expect(screen.getByText("This is a custom message")).toBeInTheDocument();
    });

    it("should not render message element when not provided", () => {
      renderModal([{ source: "github:owner/repo" }]);

      // No message should be present
      const modal = screen.getByTestId("plugin-launch-modal");
      expect(modal.querySelector("p.text-neutral-400")).not.toBeInTheDocument();
    });
  });

  describe("Expandable Sections", () => {
    it("should expand plugin section by default when it has parameters", () => {
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { apiKey: "test-key" },
        },
      ]);

      // Parameter input should be visible (section is expanded)
      expect(screen.getByTestId("plugin-0-param-apiKey")).toBeInTheDocument();
    });

    it("should collapse/expand section when clicking header", async () => {
      const user = userEvent.setup();
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { apiKey: "test-key" },
        },
      ]);

      // Initially expanded - parameter visible
      expect(screen.getByTestId("plugin-0-param-apiKey")).toBeInTheDocument();

      // Click to collapse
      await user.click(screen.getByTestId("plugin-section-0"));

      // Parameter should be hidden
      await waitFor(() => {
        expect(
          screen.queryByTestId("plugin-0-param-apiKey"),
        ).not.toBeInTheDocument();
      });

      // Click to expand again
      await user.click(screen.getByTestId("plugin-section-0"));

      // Parameter should be visible again
      await waitFor(() => {
        expect(screen.getByTestId("plugin-0-param-apiKey")).toBeInTheDocument();
      });
    });
  });

  describe("Parameter Inputs", () => {
    it("should render text input for string parameters", () => {
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { name: "default-name" },
        },
      ]);

      const input = screen.getByTestId("plugin-0-param-name");
      expect(input).toHaveAttribute("type", "text");
      expect(input).toHaveValue("default-name");
    });

    it("should render number input for number parameters", () => {
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { count: 42 },
        },
      ]);

      const input = screen.getByTestId("plugin-0-param-count");
      expect(input).toHaveAttribute("type", "number");
      expect(input).toHaveValue(42);
    });

    it("should render checkbox for boolean parameters", () => {
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { enabled: true },
        },
      ]);

      const checkbox = screen.getByTestId("plugin-0-param-enabled");
      expect(checkbox).toHaveAttribute("type", "checkbox");
      expect(checkbox).toBeChecked();
    });

    it("should update string parameter value when typing", async () => {
      const user = userEvent.setup();
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { apiKey: "initial" },
        },
      ]);

      const input = screen.getByTestId("plugin-0-param-apiKey");
      await user.clear(input);
      await user.type(input, "new-value");

      expect(input).toHaveValue("new-value");
    });

    it("should update number parameter value when typing", async () => {
      const user = userEvent.setup();
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { count: 5 },
        },
      ]);

      const input = screen.getByTestId("plugin-0-param-count");
      fireEvent.change(input, { target: { value: "100" } });

      expect(input).toHaveValue(100);
    });

    it("should toggle boolean parameter when clicking checkbox", async () => {
      const user = userEvent.setup();
      renderModal([
        {
          source: "github:owner/repo",
          parameters: { debug: false },
        },
      ]);

      const checkbox = screen.getByTestId("plugin-0-param-debug");
      expect(checkbox).not.toBeChecked();

      await user.click(checkbox);

      expect(checkbox).toBeChecked();
    });
  });

  describe("Ref and Path Display", () => {
    it("should display ref when provided", async () => {
      renderModal([
        {
          source: "github:owner/repo",
          ref: "v1.2.3",
          parameters: { key: "value" },
        },
      ]);

      // Check the expanded section contains the ref value
      const modal = screen.getByTestId("plugin-launch-modal");
      expect(modal.textContent).toContain("v1.2.3");
    });

    it("should display repo_path when provided", () => {
      renderModal([
        {
          source: "github:owner/repo",
          repo_path: "plugins/my-plugin",
          parameters: { key: "value" },
        },
      ]);

      // Check the expanded section contains the path value
      const modal = screen.getByTestId("plugin-launch-modal");
      expect(modal.textContent).toContain("plugins/my-plugin");
    });
  });

  describe("Plugins Without Parameters", () => {
    it("should show plugins list when all plugins have no parameters", () => {
      renderModal([
        { source: "github:owner/plugin1" },
        { source: "github:owner/plugin2" },
      ]);

      expect(screen.getByText("LAUNCH$PLUGINS")).toBeInTheDocument();
      // When no repo_path, the full repo path is shown (may appear multiple times)
      expect(screen.getAllByText("owner/plugin1").length).toBeGreaterThan(0);
      expect(screen.getAllByText("owner/plugin2").length).toBeGreaterThan(0);
    });

    it("should show 'Additional Plugins' when mixing plugins with and without params", () => {
      renderModal([
        { source: "github:owner/with-params", parameters: { key: "val" } },
        { source: "github:owner/without-params" },
      ]);

      expect(screen.getByText("LAUNCH$ADDITIONAL_PLUGINS")).toBeInTheDocument();
      // When no repo_path, the full repo path is shown
      expect(
        screen.getAllByText("owner/without-params").length,
      ).toBeGreaterThan(0);
    });

    it("should show ref in simple plugin list", () => {
      renderModal([{ source: "github:owner/plugin", ref: "main" }]);

      expect(screen.getByText("@ main")).toBeInTheDocument();
    });

    it("should show repo_path in simple plugin list", () => {
      renderModal([
        { source: "github:owner/repo", repo_path: "plugins/city-weather" },
      ]);

      // Should show the plugin name
      expect(screen.getByText("city-weather")).toBeInTheDocument();
      // Should show the source info with path
      const modal = screen.getByTestId("plugin-launch-modal");
      expect(modal.textContent).toContain("owner/repo");
      expect(modal.textContent).toContain("plugins/city-weather");
    });
  });

  describe("Action Buttons", () => {
    it("should call onClose when close button is clicked", async () => {
      const user = userEvent.setup();
      renderModal([{ source: "github:owner/repo" }]);

      await user.click(screen.getByTestId("close-button"));

      expect(mockOnClose).toHaveBeenCalledTimes(1);
    });

    it("should call onStartConversation with updated plugins when start button is clicked", async () => {
      const user = userEvent.setup();
      renderModal([
        {
          source: "github:owner/repo",
          ref: "main",
          parameters: { apiKey: "initial" },
        },
      ]);

      // Update the parameter
      const input = screen.getByTestId("plugin-0-param-apiKey");
      await user.clear(input);
      await user.type(input, "updated-key");

      // Check the trust checkbox first
      await user.click(screen.getByTestId("trust-checkbox"));

      // Click start
      await user.click(screen.getByTestId("start-conversation-button"));

      expect(mockOnStartConversation).toHaveBeenCalledTimes(1);
      const calledWithPlugins = mockOnStartConversation.mock.calls[0][0];
      const calledWithMessage = mockOnStartConversation.mock.calls[0][1];
      expect(calledWithPlugins[0].source).toBe("github:owner/repo");
      expect(calledWithPlugins[0].ref).toBe("main");
      expect(calledWithPlugins[0].parameters.apiKey).toBe("updated-key");
      expect(calledWithMessage).toBeUndefined();
    });

    it("should call onStartConversation with message when provided", async () => {
      const user = userEvent.setup();
      renderModal([{ source: "github:owner/repo" }], {
        message: "/city-weather:now Tokyo",
      });

      // Check the trust checkbox first
      await user.click(screen.getByTestId("trust-checkbox"));

      await user.click(screen.getByTestId("start-conversation-button"));

      expect(mockOnStartConversation).toHaveBeenCalledTimes(1);
      const calledWithPlugins = mockOnStartConversation.mock.calls[0][0];
      const calledWithMessage = mockOnStartConversation.mock.calls[0][1];
      expect(calledWithPlugins[0].source).toBe("github:owner/repo");
      expect(calledWithMessage).toBe("/city-weather:now Tokyo");
    });

    it("should show 'Starting...' text when loading", () => {
      renderModal([{ source: "github:owner/repo" }], { isLoading: true });

      expect(screen.getByText("LAUNCH$STARTING")).toBeInTheDocument();
    });

    it("should disable start button when loading", () => {
      renderModal([{ source: "github:owner/repo" }], { isLoading: true });

      expect(screen.getByTestId("start-conversation-button")).toBeDisabled();
    });
  });

  describe("Multiple Plugins with Parameters", () => {
    it("should render multiple expandable sections for plugins with parameters", () => {
      renderModal([
        { source: "github:owner/plugin1", parameters: { key1: "val1" } },
        { source: "github:owner/plugin2", parameters: { key2: "val2" } },
      ]);

      expect(screen.getByTestId("plugin-section-0")).toBeInTheDocument();
      expect(screen.getByTestId("plugin-section-1")).toBeInTheDocument();
    });

    it("should maintain separate state for each plugin's parameters", async () => {
      const user = userEvent.setup();
      renderModal([
        { source: "github:owner/plugin1", parameters: { key1: "val1" } },
        { source: "github:owner/plugin2", parameters: { key2: "val2" } },
      ]);

      // Update first plugin's parameter
      const input1 = screen.getByTestId("plugin-0-param-key1");
      await user.clear(input1);
      await user.type(input1, "new-val1");

      // Second plugin's parameter should be unchanged
      const input2 = screen.getByTestId("plugin-1-param-key2");
      expect(input2).toHaveValue("val2");

      // First plugin should have new value
      expect(input1).toHaveValue("new-val1");
    });
  });
});

describe("unsupported backend plugin parameters", () => {
  it("explains the unsupported configuration and prevents starting even after trust", async () => {
    const user = userEvent.setup();
    renderModal([{ source: "local-plugin", parameters: { city: "Paris" } }], {
      parametersSupported: false,
    });
    await user.type(screen.getByTestId("plugin-0-param-city"), " test");
    await user.click(screen.getByTestId("trust-checkbox"));

    expect(screen.getByRole("alert")).toHaveTextContent(
      "LAUNCH$PARAMETERS_UNSUPPORTED_LOCAL",
    );
    expect(screen.getByTestId("start-conversation-button")).toBeDisabled();
    await user.click(screen.getByTestId("start-conversation-button"));
    expect(mockOnStartConversation).not.toHaveBeenCalled();
  });

  it("allows coordinate-only plugins when parameters are unsupported", async () => {
    const user = userEvent.setup();
    renderModal([{ source: "local-plugin", parameters: {} }], {
      parametersSupported: false,
    });
    await user.click(screen.getByTestId("trust-checkbox"));
    await user.click(screen.getByTestId("start-conversation-button"));

    expect(mockOnStartConversation).toHaveBeenCalledWith(
      [{ source: "local-plugin", parameters: {} }],
      undefined,
    );
  });
});

describe("automation mode preflight", () => {
  const cronPreflight = {
    description: "A recipe automation",
    resolvedRef: "main",
    fields: [
      { key: "repo", type: "string", label: "repo", required: false },
      {
        key: "style",
        type: "string",
        label: "style",
        required: false,
        options: ["compact", "full"],
        defaultValue: "compact",
      },
    ] as SchemaFormField[],
    suggestedTrigger: { type: "cron", schedule: "0 9 * * *", timezone: "UTC" },
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("shows the preflight description and editable cron trigger", async () => {
    renderModal([{ source: "github:org/recipe" }], {
      mode: "automation",
      preflight: cronPreflight,
    });

    expect(
      screen.getByTestId("plugin-preflight-description"),
    ).toHaveTextContent("A recipe automation");
    expect(screen.getByTestId("plugin-trigger-schedule")).toHaveValue(
      "0 9 * * *",
    );
    expect(screen.getByTestId("plugin-trigger-timezone")).toHaveValue("UTC");
  });

  it("passes the edited cron trigger on install", async () => {
    const user = userEvent.setup();
    renderModal([{ source: "github:org/recipe" }], {
      mode: "automation",
      preflight: cronPreflight,
    });

    await user.clear(screen.getByTestId("plugin-trigger-schedule"));
    await user.type(
      screen.getByTestId("plugin-trigger-schedule"),
      "*/15 * * * *",
    );
    await user.click(screen.getByTestId("trust-checkbox"));
    await user.click(screen.getByTestId("start-conversation-button"));

    expect(mockOnInstallAutomation).toHaveBeenCalledWith(
      [
        {
          source: "github:org/recipe",
          parameters: { style: "compact" },
        },
      ],
      { type: "cron", schedule: "*/15 * * * *", timezone: "UTC" },
    );
  });

  it("renders enum schema fields as selects with help text", () => {
    renderModal(
      [{ source: "github:org/recipe", parameters: { style: "full" } }],
      {
        mode: "automation",
        preflight: {
          ...cronPreflight,
          fields: [
            { key: "repo", type: "string", label: "repo", required: false },
            {
              key: "style",
              type: "string",
              label: "style",
              required: false,
              options: ["compact", "full"],
              helpText: "Report style",
            },
          ],
        },
      },
    );

    const select = screen.getByTestId("plugin-0-param-style");
    expect(select.tagName).toBe("SELECT");
    expect(screen.getByText("Report style")).toBeInTheDocument();
  });

  it("submits the raw numeric value when a numeric enum option is selected", async () => {
    const user = userEvent.setup();
    renderModal(
      [{ source: "github:org/recipe", parameters: { priority: 1 } }],
      {
        mode: "automation",
        preflight: {
          ...cronPreflight,
          fields: [
            {
              key: "priority",
              type: "number",
              label: "priority",
              required: false,
              options: ["0", "1", "2"],
              enumValues: [0, 1, 2],
            },
          ],
        },
      },
    );

    const select = screen.getByTestId(
      "plugin-0-param-priority",
    ) as HTMLSelectElement;
    expect(select.tagName).toBe("SELECT");

    // Change to the third option (value "2"); the submit should carry the
    // raw number 2, not the string "2".
    await user.selectOptions(select, "2");
    await user.click(screen.getByTestId("trust-checkbox"));
    await user.click(screen.getByTestId("start-conversation-button"));

    expect(mockOnInstallAutomation).toHaveBeenCalledTimes(1);
    const submitted = mockOnInstallAutomation.mock.calls[0][0] as PluginSpec[];
    expect(submitted[0].parameters).toEqual({ priority: 2 });
    expect(typeof submitted[0].parameters?.priority).toBe("number");
  });

  it("renders a stale badge value as a disabled placeholder so display and submission agree", async () => {
    const user = userEvent.setup();
    // The badge pre-encodes mode: "fast", but the schema enum only allows
    // "compact"/"full". The select must show the raw value (not "— select —")
    // and submit it unchanged so the user isn't surprised by a 422.
    renderModal(
      [{ source: "github:org/recipe", parameters: { mode: "fast" } }],
      {
        mode: "automation",
        preflight: {
          ...cronPreflight,
          fields: [
            {
              key: "mode",
              type: "string",
              label: "mode",
              required: false,
              options: ["compact", "full"],
            },
          ],
        },
      },
    );

    const select = screen.getByTestId(
      "plugin-0-param-mode",
    ) as HTMLSelectElement;
    // The stale value is surfaced as a disabled option carrying the raw value.
    const staleOption = screen.getByText("fast (current)") as HTMLOptionElement;
    expect(staleOption.disabled).toBe(true);
    // The select's current value is the raw badge value, not the placeholder.
    expect(select.value).toBe("fast");

    await user.click(screen.getByTestId("trust-checkbox"));
    await user.click(screen.getByTestId("start-conversation-button"));

    expect(mockOnInstallAutomation).toHaveBeenCalledTimes(1);
    const submitted = mockOnInstallAutomation.mock.calls[0][0] as PluginSpec[];
    expect(submitted[0].parameters).toEqual({ mode: "fast" });
  });

  it("installs without an explicit trigger when preflight has no cron suggestion", async () => {
    const user = userEvent.setup();
    renderModal([{ source: "github:org/recipe" }], {
      mode: "automation",
      preflight: {
        ...cronPreflight,
        suggestedTrigger: null,
      },
    });

    expect(
      screen.queryByTestId("plugin-trigger-schedule"),
    ).not.toBeInTheDocument();
    await user.click(screen.getByTestId("trust-checkbox"));
    await user.click(screen.getByTestId("start-conversation-button"));

    expect(mockOnInstallAutomation).toHaveBeenCalledTimes(1);
    expect(mockOnInstallAutomation.mock.calls[0][1]).toBeNull();
    expect(mockOnInstallAutomation.mock.calls[0][0]).toEqual([
      {
        source: "github:org/recipe",
        parameters: { style: "compact" },
      },
    ]);
  });

  it("renders the schema label and help text instead of the raw key", () => {
    renderModal(
      [{ source: "github:org/recipe", parameters: { repo: "org/repo" } }],
      {
        mode: "automation",
        preflight: {
          ...cronPreflight,
          fields: [
            {
              key: "repo",
              type: "string",
              label: "Repository",
              required: false,
              helpText: "Which repo to scan",
            },
          ],
        },
      },
    );

    expect(screen.getByText("Repository")).toBeInTheDocument();
    expect(screen.getByText("Which repo to scan")).toBeInTheDocument();
    expect(screen.queryByText("repo")).not.toBeInTheDocument();
  });

  it("renders textarea fields with a multi-line input", () => {
    renderModal(
      [{ source: "github:org/recipe", parameters: { feeds: "a\nb" } }],
      {
        mode: "automation",
        preflight: {
          ...cronPreflight,
          fields: [
            {
              key: "feeds",
              type: "string",
              label: "Feeds",
              required: false,
              widget: "textarea",
            },
          ],
        },
      },
    );

    const input = screen.getByTestId("plugin-0-param-feeds");
    expect(input.tagName).toBe("TEXTAREA");
    expect(input).toHaveValue("a\nb");
  });
});
