import { describe, expect, it } from "vitest";
import { HttpError } from "@openhands/typescript-client";
import {
  extractDraftDispatchErrors,
  getDraftExecutionStatusText,
  formFromServerDraft,
  setupDraftFromServerDraft,
} from "#/components/features/automations/setup/automation-setup-draft-service";
import type { AutomationSetupFormValues } from "#/api/automation-setup-types";
import { AutomationRunStatus } from "#/types/automation";
import { I18nKey } from "#/i18n/declaration";
import type { AutomationDraftApiResponse } from "#/manifests/types";

const detailEnvelope = {
  detail: {
    message: "Draft is not dispatchable",
    errors: [
      {
        field: "prompt",
        code: "required",
        message: "Prompt is required",
      },
    ],
  },
};

describe("extractDraftDispatchErrors", () => {
  it("reads FastAPI detail envelopes from axios draft dispatch errors", () => {
    const error = {
      isAxiosError: true,
      response: { data: detailEnvelope },
    };

    expect(extractDraftDispatchErrors(error)).toBe("Prompt is required");
  });

  it("reads FastAPI detail envelopes from SDK HttpError draft dispatch errors", () => {
    const error = new HttpError(422, "Unprocessable Entity", detailEnvelope);

    expect(extractDraftDispatchErrors(error)).toBe("Prompt is required");
  });

  it("falls back to the detail message when no field errors are present", () => {
    const error = new HttpError(422, "Unprocessable Entity", {
      detail: { message: "Draft is not dispatchable", errors: [] },
    });

    expect(extractDraftDispatchErrors(error)).toBe("Draft is not dispatchable");
  });
});

const baseSavedDraft: AutomationDraftApiResponse = {
  id: "draft-1",
  endpoint: "/v1/preset/prompt",
  name: "Saved draft",
  draft: {},
  validationErrors: null,
  dispatchable: true,
  sourceAutomationId: null,
  materializedAutomationId: null,
  lastTestRunId: null,
  createdAt: "2026-01-01T00:00:00.000Z",
  updatedAt: "2026-01-01T00:00:00.000Z",
};

describe("getDraftExecutionStatusText", () => {
  const run = {
    id: "run-1",
    status: AutomationRunStatus.COMPLETED,
    conversation_id: null,
    bash_command_id: null,
    error_detail: null,
    started_at: "2026-01-01T00:00:00Z",
    completed_at: "2026-01-01T00:01:00Z",
  };
  const translate = (key: I18nKey) => String(key);

  it.each([
    AutomationRunStatus.COMPLETED,
    AutomationRunStatus.FAILED,
    AutomationRunStatus.RUNNING,
  ])(
    "shows the current draft error ahead of a historical %s test",
    (status) => {
      const invalidDraft = {
        ...baseSavedDraft,
        dispatchable: false,
        validationErrors: [
          {
            field: "trigger",
            code: "invalid",
            message: "Invalid cron expression: every day",
          },
        ],
      };

      const text = getDraftExecutionStatusText(
        invalidDraft,
        [{ ...run, status }],
        translate,
      );

      expect(text).toBe("Invalid cron expression: every day");
    },
  );

  it("keeps the successful test status for a currently valid draft", () => {
    expect(getDraftExecutionStatusText(baseSavedDraft, [run], translate)).toBe(
      I18nKey.AUTOMATION_SETUP$LATEST_TEST_PASSED,
    );
  });
});

const baseForm: AutomationSetupFormValues = {
  name: "",
  runAsUserId: "",
  prompt: "",
  repository: "",
  pluginSource: "",
  pluginRef: "",
  pluginConfig: "{}",
  pluginList: "",
  customCode: "",
  entrypoint: "",
  setupScriptPath: "",
  setupScript: "",
  triggerKind: "cron",
  frequency: "daily",
  time: "09:00",
  scheduleDateTime: "",
  timezone: "UTC",
  weekday: "1",
  customSchedule: "",
  eventSource: "github",
  eventKey: "",
  eventFilter: "",
  model: "",
  agentProfileId: "",
  showTimeout: false,
  timeoutSeconds: "",
  kind: "prompt",
};

describe("setupDraftFromServerDraft", () => {
  it("hydrates repositories, event keys, and run-as from saved drafts", () => {
    const saved = {
      ...baseSavedDraft,
      draft: {
        prompt: "Triage issues",
        run_as_user_id: "sa-1",
        repos: [{ url: "acme/one" }, { url: "acme/two" }],
        trigger: {
          type: "event",
          source: "github",
          on: ["pull_request", "issues"],
        },
      },
    } satisfies AutomationDraftApiResponse;

    const draft = setupDraftFromServerDraft(saved);

    expect(draft.form?.repository).toBe("acme/one, acme/two");
    expect(draft.form?.eventKey).toBe("pull_request,issues");
    expect(draft.form?.runAsUserId).toBe("sa-1");
  });

  it("updates an existing form with repositories, event keys, and run-as", () => {
    const saved = {
      ...baseSavedDraft,
      draft: {
        run_as_user_id: "sa-2",
        repos: [{ url: "acme/one" }, { url: "acme/two" }],
        trigger: {
          type: "event",
          source: "github",
          on: ["push", "release.published"],
        },
      },
    } satisfies AutomationDraftApiResponse;

    const form = formFromServerDraft(saved, {
      ...baseForm,
      runAsUserId: "stale-selection",
    });

    expect(form.repository).toBe("acme/one, acme/two");
    expect(form.eventKey).toBe("push,release.published");
    expect(form.runAsUserId).toBe("sa-2");
  });
});
