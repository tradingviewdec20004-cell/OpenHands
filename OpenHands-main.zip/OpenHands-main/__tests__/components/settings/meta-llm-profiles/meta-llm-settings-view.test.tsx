import { describe, expect, it, vi, beforeEach, type Mock } from "vitest";
import { fireEvent, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { HttpError } from "@openhands/typescript-client";
import { renderWithProviders } from "test-utils";
import { MetaLlmSettingsView } from "#/components/features/settings/meta-llm-profiles";
import * as useMetaProfilesHook from "#/hooks/query/use-meta-profiles";
import * as useLlmProfilesHook from "#/hooks/query/use-llm-profiles";
import * as useProviderConnectionsHook from "#/hooks/query/use-provider-connections";
import * as useSaveMetaProfileHook from "#/hooks/mutation/use-save-meta-profile";
import * as useActivateMetaProfileHook from "#/hooks/mutation/use-activate-meta-profile";
import * as useDeleteMetaProfileHook from "#/hooks/mutation/use-delete-meta-profile";
import * as useSettingsHook from "#/hooks/query/use-settings";
import * as useSaveSettingsHook from "#/hooks/mutation/use-save-settings";
import MetaProfilesService from "#/api/meta-profiles-service/meta-profiles-service.api";
import ProfilesService from "#/api/profiles-service/profiles-service.api";
import {
  DEFAULT_ROUTER_PRO_META_PROFILE_DEFAULT,
  DEFAULT_ROUTER_PRO_META_PROFILE_NAME,
  DEFAULT_ROUTER_FLASH_META_PROFILE_DEFAULT,
  DEFAULT_ROUTER_FLASH_META_PROFILE_NAME,
} from "#/components/features/settings/meta-llm-profiles/default-meta-profile";
import { collectRequiredRouterModelNames } from "#/components/features/settings/meta-llm-profiles/router-profiles";
import {
  displayErrorToast,
  displaySuccessToast,
} from "#/utils/custom-toast-handlers";

vi.mock("#/hooks/query/use-meta-profiles");
vi.mock("#/hooks/query/use-llm-profiles");
vi.mock("#/hooks/query/use-provider-connections");
vi.mock("#/hooks/mutation/use-save-meta-profile");
vi.mock("#/hooks/mutation/use-activate-meta-profile");
vi.mock("#/hooks/mutation/use-delete-meta-profile");
vi.mock("#/hooks/query/use-settings");
vi.mock("#/hooks/mutation/use-save-settings");
vi.mock("#/api/meta-profiles-service/meta-profiles-service.api");
vi.mock("#/api/profiles-service/profiles-service.api");
vi.mock("#/utils/custom-toast-handlers", () => ({
  displayErrorToast: vi.fn(),
  displaySuccessToast: vi.fn(),
}));
const routerPerProfileMock = vi.hoisted(() => vi.fn(() => false));
vi.mock("#/api/agent-profiles-service/profile-field-support", () => ({
  agentProfileSupportsRouter: () => routerPerProfileMock(),
}));

const mockMetaProfiles = [
  {
    name: "balanced",
    classifier_model: "minimax",
    num_classes: 0,
  },
  {
    name: "cheap",
    classifier_model: "minimax",
    num_classes: 0,
  },
];

const mockLlmProfiles = [
  { name: "minimax", model: "m", base_url: null, api_key_set: true },
  { name: "gpt", model: "g", base_url: null, api_key_set: true },
  { name: "deepseek", model: "d", base_url: null, api_key_set: true },
];

const mockProviderConnections = [
  {
    id: "conn-openhands",
    display_name: "OpenHands",
    provider: "openhands",
    base_url: null,
    created_at: 0,
    updated_at: 0,
    api_key_set: true,
  },
];

function mockMutation<T>(mutateAsync: Mock, overrides: Partial<T> = {}): T {
  return {
    mutateAsync,
    // Component code uses `mutate` (fire-and-forget) for settings saves, so
    // route it through the same mock as `mutateAsync` to stay observable.
    mutate: mutateAsync,
    isPending: false,
    isError: false,
    isSuccess: false,
    error: null,
    data: undefined,
    reset: vi.fn(),
    status: "idle",
    isIdle: true,
    ...overrides,
  } as T;
}

describe("MetaLlmSettingsView", () => {
  const activateMutateAsync = vi.fn();
  const saveMutateAsync = vi.fn();
  const saveSettingsMutate = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    routerPerProfileMock.mockReturnValue(false);

    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: {
        meta_profiles: mockMetaProfiles,
        active_meta_profile: "balanced",
      },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    vi.mocked(useLlmProfilesHook.useLlmProfiles).mockReturnValue({
      data: { profiles: mockLlmProfiles, active_profile: "minimax" },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useLlmProfilesHook.useLlmProfiles>);

    vi.mocked(
      useProviderConnectionsHook.useProviderConnections,
    ).mockReturnValue({
      data: mockProviderConnections,
      isLoading: false,
      error: null,
    } as unknown as ReturnType<
      typeof useProviderConnectionsHook.useProviderConnections
    >);

    vi.mocked(useSaveMetaProfileHook.useSaveMetaProfile).mockReturnValue(
      mockMutation(saveMutateAsync),
    );
    vi.mocked(
      useActivateMetaProfileHook.useActivateMetaProfile,
    ).mockReturnValue(mockMutation(activateMutateAsync));
    // The delete hook is consumed by the modal that is always mounted.
    vi.mocked(useDeleteMetaProfileHook.useDeleteMetaProfile).mockReturnValue(
      mockMutation(vi.fn()),
    );
    vi.mocked(useSettingsHook.useSettings).mockReturnValue({
      data: { run_router_at_conversation_start: false } as never,
      isLoading: false,
      error: null,
    } as never);
    vi.mocked(useSaveSettingsHook.useSaveSettings).mockReturnValue(
      mockMutation(saveSettingsMutate),
    );
    vi.mocked(ProfilesService.getProfile).mockResolvedValue({
      name: "minimax",
      api_key_set: true,
      config: {
        model: "litellm_proxy/template",
        base_url: "https://llm-proxy.example",
        api_key: "gAAAA_encrypted",
      },
    });
    vi.mocked(ProfilesService.saveProfile).mockResolvedValue({
      name: "created-profile",
      message: "Profile saved",
    });
  });

  it("renders the list of meta-profiles with an active badge", () => {
    renderWithProviders(<MetaLlmSettingsView />);

    expect(screen.getByTestId("meta-profile-row-balanced")).toBeInTheDocument();
    expect(screen.getByTestId("meta-profile-row-cheap")).toBeInTheDocument();
    // Only the active one shows the badge
    expect(screen.getAllByTestId("meta-profile-active-badge")).toHaveLength(1);
  });

  it("renders the list heading and router names in the theme's contrast ink", () => {
    // Literal white is invisible on light palettes (#17918); `text-contrast`
    // follows the selected color theme like the LLM profiles list does.
    renderWithProviders(<MetaLlmSettingsView />);

    const heading = screen.getByRole("heading", {
      name: "SETTINGS$META_PROFILES_AVAILABLE",
    });
    const routerName = within(
      screen.getByTestId("meta-profile-row-balanced"),
    ).getByText("balanced");

    for (const element of [heading, routerName]) {
      expect(element).toHaveClass("text-contrast");
      expect(element).not.toHaveClass("text-white");
    }
  });

  it("shows the empty state when there are no meta-profiles", () => {
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(screen.getByTestId("meta-profile-empty")).toBeInTheDocument();
  });

  it("hints when there are no LLM profiles to route between", () => {
    vi.mocked(useLlmProfilesHook.useLlmProfiles).mockReturnValue({
      data: { profiles: [], active_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useLlmProfilesHook.useLlmProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(
      screen.getByTestId("meta-profile-no-llm-profiles"),
    ).toBeInTheDocument();
  });

  const openRouterProTemplate = async (
    user: ReturnType<typeof userEvent.setup>,
  ) => {
    await user.click(screen.getByTestId("add-meta-profile"));
    await user.click(screen.getByTestId("meta-profile-template-router-pro"));
  };

  it("opens the template chooser when clicking Add Model Router", async () => {
    const user = userEvent.setup();
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("add-meta-profile"));

    expect(
      screen.getByTestId("meta-profile-template-modal"),
    ).toBeInTheDocument();
    expect(
      screen.getByTestId("meta-profile-template-router-pro"),
    ).toBeEnabled();
    expect(
      screen.getByTestId("meta-profile-template-router-flash"),
    ).toBeEnabled();
    expect(screen.getByTestId("meta-profile-template-custom")).toBeEnabled();
  });

  it("opens the Router Pro default editor from the template chooser", async () => {
    const user = userEvent.setup();
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);

    expect(screen.getByTestId("meta-profile-editor")).toBeInTheDocument();
    expect(screen.getByTestId("meta-profile-name-input")).toHaveValue(
      DEFAULT_ROUTER_PRO_META_PROFILE_NAME,
    );
  });

  it("opens the Router Flash default editor from the template chooser", async () => {
    const user = userEvent.setup();
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("add-meta-profile"));
    await user.click(screen.getByTestId("meta-profile-template-router-flash"));

    expect(screen.getByTestId("meta-profile-name-input")).toHaveValue(
      DEFAULT_ROUTER_FLASH_META_PROFILE_NAME,
    );
    expect(screen.getByTestId("meta-profile-prompt-template")).toHaveValue(
      DEFAULT_ROUTER_FLASH_META_PROFILE_DEFAULT.prompt_template,
    );
    expect(screen.getByTestId("meta-profile-model-table")).toHaveValue(
      DEFAULT_ROUTER_FLASH_META_PROFILE_DEFAULT.model_table,
    );
    // The built-in templates pre-select the first provider connection so the
    // router's LLM profiles are created on save.
    expect(screen.getByTestId("meta-profile-router-connection")).toHaveValue(
      "OpenHands (openhands)",
    );
  });

  it("opens a blank custom editor from the template chooser", async () => {
    const user = userEvent.setup();
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("add-meta-profile"));
    await user.click(screen.getByTestId("meta-profile-template-custom"));

    expect(screen.getByTestId("meta-profile-name-input")).toHaveValue("");
    expect(screen.getByTestId("meta-profile-classifier-input")).toHaveValue("");
    expect(screen.getByTestId("meta-profile-prompt-template")).toHaveValue("");
    expect(screen.getByTestId("meta-profile-model-table")).toHaveValue("");
    // Custom profiles default to "don't create profiles".
    expect(
      screen.getByTestId("meta-profile-router-connection"),
    ).not.toHaveValue("OpenHands (openhands)");
  });

  it("creates missing router LLM profiles linked to the selected provider connection", async () => {
    const user = userEvent.setup();
    saveMutateAsync.mockResolvedValue({ name: "openhands-router-pro" });
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.click(screen.getByTestId("meta-profile-save"));

    // Every model in the built-in table (plus the classifier) that is not
    // already a saved profile is created, linked to the connection.
    const expectedNames = collectRequiredRouterModelNames(
      DEFAULT_ROUTER_PRO_META_PROFILE_DEFAULT,
    ).filter((n) => !["minimax", "gpt", "deepseek"].includes(n.toLowerCase()));

    await waitFor(() =>
      expect(ProfilesService.saveProfile).toHaveBeenCalledWith("gpt-5.4", {
        llm: {
          model: "openhands/gpt-5.4",
          usage_id: "gpt-5.4",
          provider_connection_id: "conn-openhands",
        },
        include_secrets: true,
      }),
    );
    expect(ProfilesService.saveProfile).toHaveBeenCalledTimes(
      expectedNames.length,
    );
    // Router profiles reuse shared credentials via the connection, so they
    // must not clone an active profile's key.
    expect(ProfilesService.getProfile).not.toHaveBeenCalled();
    await waitFor(() => expect(saveMutateAsync).toHaveBeenCalled());
  });

  it("creates the classifier model when no LLM profiles exist yet", async () => {
    const user = userEvent.setup();
    saveMutateAsync.mockResolvedValue({ name: "openhands-router-pro" });
    // No saved LLM profiles and no active meta-profile (fresh install).
    vi.mocked(useLlmProfilesHook.useLlmProfiles).mockReturnValue({
      data: { profiles: [], active_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useLlmProfilesHook.useLlmProfiles>);
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.click(screen.getByTestId("meta-profile-save"));

    // The classifier model must be created just like the routed models.
    await waitFor(() =>
      expect(ProfilesService.saveProfile).toHaveBeenCalledWith("minimax-m3", {
        llm: {
          model: "openhands/minimax-m3",
          usage_id: "minimax-m3",
          provider_connection_id: "conn-openhands",
        },
        include_secrets: true,
      }),
    );
    // ...and every required model (table + classifier) is created.
    const expectedNames = collectRequiredRouterModelNames(
      DEFAULT_ROUTER_PRO_META_PROFILE_DEFAULT,
    );
    expect(ProfilesService.saveProfile).toHaveBeenCalledTimes(
      expectedNames.length,
    );
  });

  it("activates the first meta-profile after creating it", async () => {
    const user = userEvent.setup();
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
    saveMutateAsync.mockResolvedValue({ name: "pareto" });
    activateMutateAsync.mockResolvedValue({ name: "pareto" });
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.clear(screen.getByTestId("meta-profile-name-input"));
    await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
    fireEvent.change(screen.getByTestId("meta-profile-classifier-input"), {
      target: { value: "minimax" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-prompt-template"), {
      target: { value: "Task:\n{{ instance_text }}" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
      target: { value: "" },
    });
    await user.click(screen.getByTestId("meta-profile-save"));

    await waitFor(() =>
      expect(saveMutateAsync).toHaveBeenCalledWith({
        name: "pareto",
        config: {
          classifier_model: "minimax",
          classes: [],
          prompt_template: "Task:\n{{ instance_text }}",
          model_table: null,
        },
      }),
    );
    await waitFor(() =>
      expect(activateMutateAsync).toHaveBeenCalledWith("pareto"),
    );
  });

  it("auto-enables 'Run on first message' when the first router is created", async () => {
    const user = userEvent.setup();
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
    saveMutateAsync.mockResolvedValue({ name: "pareto" });
    activateMutateAsync.mockResolvedValue({ name: "pareto" });
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.clear(screen.getByTestId("meta-profile-name-input"));
    await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
    fireEvent.change(screen.getByTestId("meta-profile-classifier-input"), {
      target: { value: "minimax" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-prompt-template"), {
      target: { value: "Task:\n{{ instance_text }}" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
      target: { value: "" },
    });
    await user.click(screen.getByTestId("meta-profile-save"));

    await waitFor(() =>
      expect(saveSettingsMutate).toHaveBeenCalledWith({
        run_router_at_conversation_start: true,
      }),
    );
  });

  it("does not touch 'Run on first message' when creating a router while others exist", async () => {
    const user = userEvent.setup();
    // A router already exists (and is active), so this is not a 0 → 1 create.
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: {
        meta_profiles: mockMetaProfiles,
        active_meta_profile: "balanced",
      },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
    saveMutateAsync.mockResolvedValue({ name: "pareto" });
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.clear(screen.getByTestId("meta-profile-name-input"));
    await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
    fireEvent.change(screen.getByTestId("meta-profile-classifier-input"), {
      target: { value: "minimax" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-prompt-template"), {
      target: { value: "Task:\n{{ instance_text }}" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
      target: { value: "" },
    });
    await user.click(screen.getByTestId("meta-profile-save"));

    await waitFor(() => expect(saveMutateAsync).toHaveBeenCalled());
    expect(saveSettingsMutate).not.toHaveBeenCalled();
  });

  it("surfaces a failed auto-enable write without aborting router creation", async () => {
    const user = userEvent.setup();
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
    saveMutateAsync.mockResolvedValue({ name: "pareto" });
    activateMutateAsync.mockResolvedValue({ name: "pareto" });
    // The auto-enable preference write fails.
    saveSettingsMutate.mockRejectedValueOnce(new Error("network"));
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.clear(screen.getByTestId("meta-profile-name-input"));
    await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
    fireEvent.change(screen.getByTestId("meta-profile-classifier-input"), {
      target: { value: "minimax" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-prompt-template"), {
      target: { value: "Task:\n{{ instance_text }}" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
      target: { value: "" },
    });
    await user.click(screen.getByTestId("meta-profile-save"));

    // The preference write was attempted...
    await waitFor(() =>
      expect(saveSettingsMutate).toHaveBeenCalledWith({
        run_router_at_conversation_start: true,
      }),
    );
    // ...its failure is surfaced...
    await waitFor(() =>
      expect(vi.mocked(displayErrorToast)).toHaveBeenCalled(),
    );
    // ...and the primary create/activate flow still completes.
    await waitFor(() =>
      expect(activateMutateAsync).toHaveBeenCalledWith("pareto"),
    );
    // The success toast is suppressed on this path so the user sees a single
    // unambiguous error rather than a success and an error for one action.
    expect(vi.mocked(displaySuccessToast)).not.toHaveBeenCalled();
  });

  it("does not auto-activate a newly-created meta-profile when one is already active", async () => {
    const user = userEvent.setup();
    saveMutateAsync.mockResolvedValue({ name: "pareto" });
    renderWithProviders(<MetaLlmSettingsView />);

    await openRouterProTemplate(user);
    await user.clear(screen.getByTestId("meta-profile-name-input"));
    await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
    fireEvent.change(screen.getByTestId("meta-profile-classifier-input"), {
      target: { value: "minimax" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-prompt-template"), {
      target: { value: "Task:\n{{ instance_text }}" },
    });
    fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
      target: { value: "" },
    });
    await user.click(screen.getByTestId("meta-profile-save"));

    await waitFor(() => expect(saveMutateAsync).toHaveBeenCalled());
    expect(activateMutateAsync).not.toHaveBeenCalled();
  });

  it("activates a meta-profile via the actions menu", async () => {
    const user = userEvent.setup();
    activateMutateAsync.mockResolvedValue({ name: "cheap" });
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("meta-profile-menu-trigger-cheap"));
    await user.click(screen.getByTestId("meta-profile-set-active"));

    await waitFor(() =>
      expect(activateMutateAsync).toHaveBeenCalledWith("cheap"),
    );
  });

  it("loads the config and opens the editor via the actions menu", async () => {
    const user = userEvent.setup();
    vi.mocked(MetaProfilesService.getMetaProfile).mockResolvedValue({
      name: "balanced",
      config: {
        classifier_model: "minimax",
        classes: [],
        prompt_template: "Route this task.\n{{ instance_text }}",
        model_table: "- GPT-5.4",
      },
    });
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("meta-profile-menu-trigger-balanced"));
    await user.click(screen.getByTestId("meta-profile-edit"));

    await waitFor(() =>
      expect(screen.getByTestId("meta-profile-editor")).toBeInTheDocument(),
    );
    expect(MetaProfilesService.getMetaProfile).toHaveBeenCalledWith("balanced");
  });

  it("shows an explicit unsupported-backend message when the API is missing (404)", () => {
    // Older backends (pre software-agent-sdk #3744) have no /api/meta-profiles
    // endpoint and return 404; the page must explain that instead of a dead
    // generic error, and must not offer Add.
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: undefined,
      isLoading: false,
      error: new HttpError(404, "Not Found"),
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(screen.getByTestId("meta-profile-unsupported")).toBeInTheDocument();
    expect(screen.queryByTestId("add-meta-profile")).not.toBeInTheDocument();
  });

  it("shows the generic error for non-404 failures", () => {
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: undefined,
      isLoading: false,
      error: new HttpError(500, "Internal Server Error"),
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(
      screen.queryByTestId("meta-profile-unsupported"),
    ).not.toBeInTheDocument();
    // The Add affordance remains for transient/server errors.
    expect(screen.getByTestId("add-meta-profile")).toBeInTheDocument();
  });

  it("disables Set active in the menu for the already-active profile", async () => {
    const user = userEvent.setup();
    renderWithProviders(<MetaLlmSettingsView />);

    await user.click(screen.getByTestId("meta-profile-menu-trigger-balanced"));

    expect(screen.getByTestId("meta-profile-set-active")).toBeDisabled();
  });

  it("renders the Run-at-conversation-start toggle disabled when no meta-profile is active", () => {
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      data: { meta_profiles: [], active_meta_profile: null },
      isLoading: false,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(
      screen.getByTestId("meta-profile-run-at-conversation-start"),
    ).toBeInTheDocument();
    expect(
      screen.getByTestId("meta-profile-run-at-conversation-start-switch"),
    ).toBeDisabled();
  });

  it("does not clear a saved on preference while the meta-profiles query is still loading", () => {
    // Regression guard for the load-time effect that destroyed the toggle:
    // ``useMetaProfiles`` returns ``active_meta_profile: null`` until the
    // fetch resolves, so a mount-time guard must NOT fire saveSettings to
    // clear a persisted ``true``. The launch paths gate on the active
    // meta-profile instead, so the preference is preserved for when a router
    // is active again.
    const saveSettingsMock = vi.fn();
    const base = mockMutation(vi.fn()) as Record<string, unknown>;
    vi.mocked(useSaveSettingsHook.useSaveSettings).mockReturnValue({
      ...base,
      mutate: saveSettingsMock,
    } as never);
    vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
      // Loading: data not yet resolved, so active is null.
      data: undefined,
      isLoading: true,
      error: null,
    } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
    vi.mocked(useSettingsHook.useSettings).mockReturnValue({
      data: { run_router_at_conversation_start: true } as never,
      isLoading: false,
      error: null,
    } as never);

    renderWithProviders(<MetaLlmSettingsView />);

    // The switch renders off (no active router) but the persisted preference
    // is left intact — saveSettings must not be called to clear it.
    expect(
      screen.getByTestId("meta-profile-run-at-conversation-start-switch"),
    ).not.toBeChecked();
    expect(saveSettingsMock).not.toHaveBeenCalled();
  });

  it("persists the Run-at-conversation-start toggle through useSaveSettings", async () => {
    const saveSettingsMock = vi.fn();
    const base = mockMutation(vi.fn()) as Record<string, unknown>;
    vi.mocked(useSaveSettingsHook.useSaveSettings).mockReturnValue({
      ...base,
      mutate: saveSettingsMock,
    } as never);
    vi.mocked(useSettingsHook.useSettings).mockReturnValue({
      data: { run_router_at_conversation_start: false } as never,
      isLoading: false,
      error: null,
    } as never);

    renderWithProviders(<MetaLlmSettingsView />);

    const user = userEvent.setup();
    const toggle = screen.getByTestId(
      "meta-profile-run-at-conversation-start-switch",
    );
    expect(toggle).not.toBeDisabled();
    // An active meta-profile is set in the default beforeEach mock.
    await user.click(toggle);

    await waitFor(() =>
      expect(saveSettingsMock).toHaveBeenCalledWith({
        run_router_at_conversation_start: true,
      }),
    );
  });

  it("reflects the persisted Run-at-conversation-start value as on", () => {
    vi.mocked(useSettingsHook.useSettings).mockReturnValue({
      data: { run_router_at_conversation_start: true } as never,
      isLoading: false,
      error: null,
    } as never);

    renderWithProviders(<MetaLlmSettingsView />);

    expect(
      screen.getByTestId("meta-profile-run-at-conversation-start-switch"),
    ).toBeChecked();
  });

  describe("when each agent profile picks its router", () => {
    beforeEach(() => {
      routerPerProfileMock.mockReturnValue(true);
    });

    it("lists routers without an active one or a Set active action", async () => {
      const user = userEvent.setup();
      renderWithProviders(<MetaLlmSettingsView />);

      expect(
        screen.queryByTestId("meta-profile-active-badge"),
      ).not.toBeInTheDocument();
      await user.click(
        screen.getByTestId("meta-profile-menu-trigger-balanced"),
      );
      expect(screen.getByTestId("meta-profile-edit")).toBeInTheDocument();
      expect(
        screen.queryByTestId("meta-profile-set-active"),
      ).not.toBeInTheDocument();
      expect(screen.getByTestId("meta-profile-delete")).toBeInTheDocument();
    });

    it("does not activate the first router after creating it", async () => {
      const user = userEvent.setup();
      vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
        data: { meta_profiles: [], active_meta_profile: null },
        isLoading: false,
        error: null,
      } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);
      saveMutateAsync.mockResolvedValue({ name: "pareto" });
      renderWithProviders(<MetaLlmSettingsView />);

      await openRouterProTemplate(user);
      await user.clear(screen.getByTestId("meta-profile-name-input"));
      await user.type(screen.getByTestId("meta-profile-name-input"), "pareto");
      fireEvent.change(screen.getByTestId("meta-profile-model-table"), {
        target: { value: "" },
      });
      await user.click(screen.getByTestId("meta-profile-save"));

      await waitFor(() => expect(saveMutateAsync).toHaveBeenCalled());
      expect(activateMutateAsync).not.toHaveBeenCalled();
    });

    it("enables Run on first message once any router exists", () => {
      vi.mocked(useMetaProfilesHook.useMetaProfiles).mockReturnValue({
        data: { meta_profiles: mockMetaProfiles, active_meta_profile: null },
        isLoading: false,
        error: null,
      } as unknown as ReturnType<typeof useMetaProfilesHook.useMetaProfiles>);

      renderWithProviders(<MetaLlmSettingsView />);

      expect(
        screen.getByTestId("meta-profile-run-at-conversation-start-switch"),
      ).not.toBeDisabled();
      expect(
        screen.getByText(
          "SETTINGS$META_PROFILE_RUN_AT_CONVERSATION_START_HELP_PROFILE",
        ),
      ).toBeInTheDocument();
    });
  });
});
